Betas are works in progress.  When a beta has a seemingly stable set
of features, we may post a public beta so outside developers can see
where the code is going and make contributions or comment.

A Release Candidate is a beta that we believe has the full feature
set that will be released.  It's still being tested, and things can
still change, but we thought it close when we posted it.

We take suggestions, bug fixes, and patches at any time, so send them in.

We make no guarantees as to the state of betas so use at your own risk.
All code, including releases, are released under the Info-ZIP license.

Enjoy!

Ed Gordon
20 April 2008
